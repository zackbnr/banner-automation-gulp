var testFunction = function() {
    var files = ['button.jpg', 'logo.png', 'product.png'];
    return files;
}
